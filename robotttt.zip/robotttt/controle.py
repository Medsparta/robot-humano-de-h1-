import mujoco
from mujoco.viewer import launch_passive
from stable_baselines3 import PPO
from test import HumanoidWalkingEnv
import numpy as np

# Charger l'environnement et le modèle PPO
env = HumanoidWalkingEnv("h1.scene.xml")
model = PPO.load("ppo_robot_humanoide")

# Modèle et données MuJoCo
model_mj = env.model
data_mj = env.data

# Action manuelle possible
current_action = np.zeros(model_mj.nu)

# Lancer le viewer MuJoCo avec contrôles
with launch_passive(model_mj, data_mj) as viewer:
    print("Contrôles clavier actifs :")
    print("  a/z → augmenter/diminuer action[0]")
    print("  r → reset simulation")
    print("  espace → pause")
    print("  esc → quitter")

    while True:
        # Obtenir observation actuelle
        obs = env._get_obs()

        # Prédire une action avec le modèle PPO
        action, _ = model.predict(obs, deterministic=True)

        # Lire la dernière touche pressée
        key = viewer.user_scn.key_last

        # Modifier l'action si touches pressées
        if key == ord('a'):
            action[0] += 0.1
        elif key == ord('z'):
            action[0] -= 0.1
        elif key == ord('r'):
            env.reset()

        # Appliquer l'action et avancer dans la simulation
        data_mj.ctrl[:] = action
        mujoco.mj_step(model_mj, data_mj)
        viewer.sync()

        # Afficher les infos du torse en temps réel
        pos_x = data_mj.qpos[0]
        pos_z = data_mj.qpos[2]
        vel_x = data_mj.qvel[0]
        print(f"X: {pos_x:.2f} | Z: {pos_z:.2f} | Vitesse X: {vel_x:.2f}", end='\r')
