from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.callbacks import EvalCallback
from test import HumanoidWalkingEnv
import os

# Chemin vers ton modèle MuJoCo
MODEL_PATH = "C:/Users/asus/robotttt/h1.scene.xml"

# 🔁 Créer un environnement avec Monitor (logging des rewards)
def make_env():
    env = HumanoidWalkingEnv(model_path=MODEL_PATH, render_mode=None)
    env = Monitor(env)  # important pour EvalCallback
    return env

# 🧠 Environnement d'entraînement avec normalisation
env = DummyVecEnv([make_env])
env = VecNormalize(env, norm_obs=True, norm_reward=True)

# 🔍 Environnement d'évaluation (pas de normalisation de reward)
eval_env = DummyVecEnv([make_env])
eval_env = VecNormalize(eval_env, training=False, norm_obs=True, norm_reward=False)

# 📊 Callback pour évaluer régulièrement le modèle
eval_callback = EvalCallback(
    eval_env,
    best_model_save_path="./logs/",
    log_path="./logs/",
    eval_freq=10_000,           # évalue tous les 10k steps
    deterministic=True,
    render=False,
)

# 🧠 Créer et entraîner le modèle PPO
model = PPO("MlpPolicy", env, verbose=1)
model.learn(total_timesteps=1_000_000, callback=eval_callback)

# 💾 Sauvegarder le modèle et normaliseur
model.save("humanoid_walk_model")
env.save("humanoid_vecnormalize.pkl")

print("✅ Entraînement terminé et modèle sauvegardé.")
