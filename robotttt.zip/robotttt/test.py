import gymnasium as gym
from gymnasium import spaces
import mujoco
import mujoco.viewer
import numpy as np
from scipy.spatial.transform import Rotation as R
import os
import time


class HumanoidWalkingEnv(gym.Env):
    metadata = {"render_modes": ["human", "rgb_array"], "render_fps": 60}

    def __init__(self, model_path, render_mode="human"):
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Fichier modèle MuJoCo non trouvé à : {model_path}")

        self.model = mujoco.MjModel.from_xml_path(model_path)
        self.data = mujoco.MjData(self.model)
        self.render_mode = render_mode
        self.viewer = None
        self.step_count = 0
        self.model.actuator_ctrlrange[:, :] = np.clip(self.model.actuator_ctrlrange, -100, 100)


        self.action_space = spaces.Box(low=-1.0, high=1.0, shape=(self.model.nu,), dtype=np.float32)
        obs_dim = self.model.nq + self.model.nv + 4 + 3 + 1
        self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(obs_dim,), dtype=np.float32)

        self.pelvis_body_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, "pelvis")
        if self.pelvis_body_id == -1:
            raise ValueError("Le corps 'pelvis' n'a pas été trouvé dans le modèle MuJoCo.")

    def _get_center_of_mass(self):
        total_mass = 0
        weighted_pos = np.zeros(3)
        for i in range(self.model.nbody):
            mass = self.model.body_mass[i]
            pos = self.data.xpos[i]
            weighted_pos += mass * pos
            total_mass += mass
            
        return weighted_pos / total_mass if total_mass > 0 else np.zeros(3)
    
       

    def _get_obs(self):
        qpos = self.data.qpos.flat.copy()
        qvel = self.data.qvel.flat.copy()
        pelvis_quat = self.data.xquat[self.pelvis_body_id].copy()
        pelvis_ang_vel = self.data.cvel[self.pelvis_body_id, 3:6].copy()
        pelvis_height = self.data.xpos[self.pelvis_body_id, 2]
        return np.concatenate([qpos, qvel, pelvis_quat, pelvis_ang_vel, [pelvis_height]]).astype(np.float32)
    
    def _get_zmp(self):
        f_ext = self.data.cfrc_ext
        com = self._get_center_of_mass()
        zmp = np.zeros(2)
  
        total_fz = 0.0
        moment = np.zeros(2)

        for i in range(self.model.nbody):
          fz = f_ext[i][2]
          px, py = self.data.xpos[i][:2]
          mx, my = f_ext[i][0], f_ext[i][1]

          total_fz += fz
          moment[0] += (-my + fz * py)
          moment[1] += (mx - fz * px)

        if total_fz != 0:
          zmp[0] = -moment[1] / total_fz
          zmp[1] = -moment[0] / total_fz

        return zmp


    def _apply_balance_controller(self):
        com = self._get_center_of_mass()
        target_xy = np.array([0.0, 0.0])
        error = target_xy - com[:2]
        derror = -self.data.qvel[:2]
        hip_roll_joints = ["left_hip_roll", "right_hip_roll"]
        hip_pitch_joints = ["left_hip_pitch", "right_hip_pitch"]
        Kp_roll = np.array([200.0, 180.0])
        Kd_roll = np.array([20.0, 15.0])
        Kp_pitch = np.array([180.0, 200.0])  
        Kd_pitch = np.array([18.0, 22.0])
        
 
        for i, joint_name in enumerate(hip_roll_joints):
            j_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_JOINT, joint_name)
            if j_id != -1:
                correction = Kp_roll[i] * error[0] + Kd_roll[i] * derror[0]
                self.data.ctrl[j_id] = np.clip(correction, -1.0, 1.0)


        for i, joint_name in enumerate(hip_roll_joints):
            j_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_JOINT, joint_name)
            if j_id != -1:
                 correction = Kp_pitch[i] * error[1] + Kd_pitch[i] * derror[1]
                 self.data.ctrl[j_id] = np.clip(correction, -1.0, 1.0)
                   # 🔄 Stabilisation active du torse (pitch)
                 torso_joint_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_JOINT, "torso")
            if torso_joint_id != -1:
                # Pitch du torse (en radians)
              pelvis_quat = self.data.xquat[self.pelvis_body_id]
              torso_pitch = R.from_quat(pelvis_quat).as_euler("xyz")[1]
              pitch_vel = self.data.qvel[torso_joint_id]
          # PID simple
        Kp_torso = 150.0
        Kd_torso = 15.0
        correction = -Kp_torso * torso_pitch - Kd_torso * pitch_vel
        # Normalisation selon ctrlrange
        max_force = self.model.actuator_ctrlrange[torso_joint_id, 1]
        correction_normalized = np.clip(correction / max_force, -1.0, 1.0)
        self.data.ctrl[torso_joint_id] = correction_normalized


    def step(self, action):
        if action is None:
            self._apply_balance_controller()
            action = np.zeros(self.model.nu)
        else:
            action = np.asarray(action, dtype=np.float32)
            action = np.clip(action, -1.0, 1.0)
            ctrlrange = self.model.actuator_ctrlrange
            scaled_action = ctrlrange[:, 0] + (action + 1.0) * 0.5 * (ctrlrange[:, 1] - ctrlrange[:, 0])
            self.data.ctrl[:] = scaled_action


        mujoco.mj_step(self.model, self.data)
        self.step_count += 1
        reward, done = self._calculate_reward()
        observation = self._get_obs()
        return observation, reward, done, False, {}

    def _calculate_reward(self):
       reward = 0.0
       done = False

    # ✅ Hauteur du bassin (encourage à rester debout)
       pelvis_height = self.data.xpos[self.pelvis_body_id, 2]
       reward += pelvis_height

    # ✅ Posture verticale du torse (up vector)
       pelvis_quat = self.data.xquat[self.pelvis_body_id]
       rot = R.from_quat(pelvis_quat)
       up_vector = np.array([0, 0, 1])
       uprightness = np.dot(rot.as_matrix()[:, 2], up_vector)
       reward += 0.5 * uprightness

    # ✅ ZMP penalty (si instable)
       zmp = self._get_zmp()
       zmp_distance = np.linalg.norm(zmp)
       if zmp_distance > 0.12:
          reward -= 10.0 * (zmp_distance - 0.12)
       try:
          qvel = self.data.qvel
          joint_pairs = [
              ("left_hip_pitch", "right_hip_pitch"),
              ("left_knee", "right_knee"),
              ("left_ankle", "right_ankle"),
              ("left_shoulder_pitch", "right_shoulder_pitch"),
              ("left_elbow", "right_elbow")
          ]
          symmetry_loss = 0.0
          for left, right in joint_pairs:
              l_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_JOINT, left)
              r_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_JOINT, right)
              if l_id != -1 and r_id != -1:
                  symmetry_loss += np.square(qvel[l_id] + qvel[r_id])
          reward -= 0.1 * symmetry_loss
       except Exception:
           pass



    # ✅ Terminer si le robot tombe trop bas
       if pelvis_height < 0.8:
          reward -= 20.0
          done = True

       return reward, done

    
    
    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        qpos = self.model.qpos0.copy()
        qpos[2] = 1.04
        qpos[3:7] = np.array([1, 0, 0, 0])
        qvel = np.zeros_like(self.data.qvel)
        qpos += self.np_random.uniform(low=-0.005, high=0.005, size=self.model.nq)
        qvel += self.np_random.uniform(low=-0.005, high=0.005, size=self.model.nv)

        self.data.qpos[:] = qpos
        self.data.qvel[:] = qvel
        mujoco.mj_forward(self.model, self.data)
        self.step_count = 0
        return self._get_obs(), {}

    def render(self):
        if self.render_mode == "human":
            if self.viewer is None:
                self.viewer = mujoco.viewer.launch_passive(self.model, self.data)
            else:
                self.viewer.sync()

    def close(self):
        if self.viewer is not None:
            self.viewer.close()
            self.viewer = None


if __name__ == "__main__":
    ROBOT_MODEL_PATH = "C:/Users/asus/robotttt/h1.scene.xml"
    try:
        env = HumanoidWalkingEnv(model_path=ROBOT_MODEL_PATH, render_mode="human")
        obs, _ = env.reset()
        for i in range(1000):
            obs, reward, done, truncated, _ = env.step(None)
            env.render()
            time.sleep(1 / 60)
            if done or truncated:
                print(f"\n🌍 Chute détectée à l’étape {i+1}. Réinitialisation...")
                obs, _ = env.reset()

        with mujoco.viewer.launch_passive(env.model, env.data) as viewer:
            while True:
                viewer.sync()
                time.sleep(0.01)

    finally:
        if 'env' in locals():
            env.close()
