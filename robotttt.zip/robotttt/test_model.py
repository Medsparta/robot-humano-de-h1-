from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize
from test import HumanoidWalkingEnv
import time

# ✅ Chemin vers ton modèle MuJoCo
MODEL_PATH = "C:/Users/asus/robotttt/h1.scene.xml"

# ✅ Charger l'environnement
def make_env():
    env = HumanoidWalkingEnv(model_path=MODEL_PATH, render_mode="human")
    return env

# ✅ Préparer l'environnement (même wrapper que pendant l'entraînement)
env = DummyVecEnv([make_env])
env = VecNormalize.load("humanoid_vecnormalize.pkl", env)
env.training = False
env.norm_reward = False

# ✅ Charger le modèle PPO entraîné
model = PPO.load("humanoid_walk_model", env=env)

# ✅ Tester le robot
obs = env.reset()
for i in range(1000):
    action, _ = model.predict(obs, deterministic=True)
    obs, reward, done, _ = env.step(action)
    env.render()
    time.sleep(1 / 60)

    if done:
        print(f"✅ Épisode terminé à l'étape {i}, reset.")
        obs = env.reset()
