from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv
from test import HumanoidWalkingEnv
import os
import time

env = HumanoidWalkingEnv(model_path="C:/Users/asus/robotttt/Untitled-1.xml", render_mode="human")

model = PPO.load("humanoid_stable_model")
 
obs, _ = env.reset()
for step in range(1000):
    action, _states = model.predict(obs, deterministic=True)
    obs, reward, done, truncated, _ = env.step(action)
    env.render()
    time.sleep(1 / 60)
    if done or truncated:
        obs, _ = env.reset()
